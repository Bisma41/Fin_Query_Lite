"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  TrendingUp,
  BarChart3,
  Target,
  Calendar,
  Activity,
  Zap,
  Brain,
  LineChart,
  Settings,
  Play,
  CheckCircle,
  XCircle,
} from "lucide-react"

import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
} from "@/components/ui/chart"
import {
  LineChart as RechartsLineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
} from "recharts"

export default function StockForecastingDashboard() {
  const [ticker, setTicker] = useState("TSLA")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisComplete, setAnalysisComplete] = useState(false)
  const [bestModel, setBestModel] = useState("Prophet")
  const [bestAccuracy, setBestAccuracy] = useState(0.6667)

  const handleRunAnalysis = async () => {
    setIsAnalyzing(true)
    // Simulate analysis process
    await new Promise((resolve) => setTimeout(resolve, 3000))
    setIsAnalyzing(false)
    setAnalysisComplete(true)
  }

  const modelResults = [
    { name: "Prophet", accuracy: 0.6667, precision: 0.71, recall: 0.75, icon: Brain },
    { name: "Random Forest", accuracy: 0.62, precision: 0.66, recall: 0.7, icon: Activity },
    { name: "XGBoost", accuracy: 0.58, precision: 0.63, recall: 0.67, icon: Zap },
    { name: "Linear Regression", accuracy: 0.55, precision: 0.59, recall: 0.63, icon: LineChart },
    { name: "SMA Baseline", accuracy: 0.52, precision: 0.56, recall: 0.6, icon: BarChart3 },
  ]

  // Detailed evaluation data for each model
  const evaluationData = {
    "Linear Regression": [
      {
        day: 4,
        actualPrice: 240.45,
        predictedPrice: 439.818,
        previousPrice: 247.49,
        actualDirection: "DOWN",
        predictedDirection: "UP",
        correct: false,
      },
      {
        day: 5,
        actualPrice: 234.96,
        predictedPrice: 741.6448,
        previousPrice: 240.45,
        actualDirection: "DOWN",
        predictedDirection: "UP",
        correct: false,
      },
      {
        day: 6,
        actualPrice: 233.94,
        predictedPrice: 781.5702,
        previousPrice: 234.96,
        actualDirection: "DOWN",
        predictedDirection: "UP",
        correct: false,
      },
      {
        day: 7,
        actualPrice: 227.22,
        predictedPrice: 560.9412,
        previousPrice: 233.94,
        actualDirection: "DOWN",
        predictedDirection: "UP",
        correct: false,
      },
      {
        day: 8,
        actualPrice: 218.89,
        predictedPrice: 752.228,
        previousPrice: 227.22,
        actualDirection: "DOWN",
        predictedDirection: "UP",
        correct: false,
      },
      {
        day: 9,
        actualPrice: 219.91,
        predictedPrice: 1003.0848,
        previousPrice: 218.89,
        actualDirection: "UP",
        predictedDirection: "UP",
        correct: true,
      },
      {
        day: 10,
        actualPrice: 215.55,
        predictedPrice: 1034.7502,
        previousPrice: 219.91,
        actualDirection: "DOWN",
        predictedDirection: "UP",
        correct: false,
      },
      {
        day: 11,
        actualPrice: 211.88,
        predictedPrice: 809.4212,
        previousPrice: 215.55,
        actualDirection: "DOWN",
        predictedDirection: "UP",
        correct: false,
      },
      {
        day: 12,
        actualPrice: 212.19,
        predictedPrice: 1240.2037,
        previousPrice: 211.88,
        actualDirection: "UP",
        predictedDirection: "UP",
        correct: true,
      },
      {
        day: 13,
        actualPrice: 208.8,
        predictedPrice: 1527.435,
        previousPrice: 212.19,
        actualDirection: "DOWN",
        predictedDirection: "UP",
        correct: false,
      },
      {
        day: 14,
        actualPrice: 209.14,
        predictedPrice: 1341.1914,
        previousPrice: 208.8,
        actualDirection: "UP",
        predictedDirection: "UP",
        correct: true,
      },
    ],
    Prophet: [
      {
        day: 4,
        actualPrice: 240.45,
        predictedPrice: 245.32,
        previousPrice: 247.49,
        actualDirection: "DOWN",
        predictedDirection: "DOWN",
        correct: true,
      },
      {
        day: 5,
        actualPrice: 234.96,
        predictedPrice: 238.15,
        previousPrice: 240.45,
        actualDirection: "DOWN",
        predictedDirection: "DOWN",
        correct: true,
      },
      {
        day: 6,
        actualPrice: 233.94,
        predictedPrice: 232.88,
        previousPrice: 234.96,
        actualDirection: "DOWN",
        predictedDirection: "DOWN",
        correct: true,
      },
      {
        day: 7,
        actualPrice: 227.22,
        predictedPrice: 231.45,
        previousPrice: 233.94,
        actualDirection: "DOWN",
        predictedDirection: "DOWN",
        correct: true,
      },
      {
        day: 8,
        actualPrice: 218.89,
        predictedPrice: 225.67,
        previousPrice: 227.22,
        actualDirection: "DOWN",
        predictedDirection: "DOWN",
        correct: true,
      },
      {
        day: 9,
        actualPrice: 219.91,
        predictedPrice: 220.34,
        previousPrice: 218.89,
        actualDirection: "UP",
        predictedDirection: "UP",
        correct: true,
      },
      {
        day: 10,
        actualPrice: 215.55,
        predictedPrice: 218.78,
        previousPrice: 219.91,
        actualDirection: "DOWN",
        predictedDirection: "DOWN",
        correct: true,
      },
      {
        day: 11,
        actualPrice: 211.88,
        predictedPrice: 214.23,
        previousPrice: 215.55,
        actualDirection: "DOWN",
        predictedDirection: "DOWN",
        correct: true,
      },
      {
        day: 12,
        actualPrice: 212.19,
        predictedPrice: 213.45,
        previousPrice: 211.88,
        actualDirection: "UP",
        predictedDirection: "UP",
        correct: true,
      },
      {
        day: 13,
        actualPrice: 208.8,
        predictedPrice: 211.67,
        previousPrice: 212.19,
        actualDirection: "DOWN",
        predictedDirection: "DOWN",
        correct: true,
      },
      {
        day: 14,
        actualPrice: 209.14,
        predictedPrice: 209.89,
        previousPrice: 208.8,
        actualDirection: "UP",
        predictedDirection: "UP",
        correct: true,
      },
    ],
  }

  const confusionMatrixData = {
    "Linear Regression": { tp: 3, fp: 8, tn: 0, fn: 0 },
    Prophet: { tp: 4, fp: 0, tn: 6, fn: 1 },
  }

  const classificationMetrics = {
    "Linear Regression": { precision: 0.2727, recall: 1.0, accuracy: 0.2727 },
    Prophet: { precision: 1.0, recall: 0.8, accuracy: 0.9091 },
  }

  // Optimization experiment data
  const horizonOptimizationData = [
    { horizon: "12 days", accuracy: 66.67 },
    { horizon: "9 days", accuracy: 77.78 },
    { horizon: "6 days", accuracy: 83.33 },
  ]

  const windowOptimizationData = [
    { window: "100", accuracy: 68 },
    { window: "200", accuracy: 71 },
    { window: "300", accuracy: 73 },
  ]

  // Final forecast data - historical + predicted
  const finalForecastData = [
    { date: "2025-05-01", price: 287.2, type: "historical" },
    { date: "2025-05-05", price: 280.1, type: "historical" },
    { date: "2025-05-06", price: 276.8, type: "historical" },
    { date: "2025-05-08", price: 285.4, type: "historical" },
    { date: "2025-05-09", price: 298.7, type: "historical" },
    { date: "2025-05-12", price: 318.2, type: "historical" },
    { date: "2025-05-13", price: 335.8, type: "historical" },
    { date: "2025-05-15", price: 347.1, type: "historical" },
    { date: "2025-05-16", price: 349.3, type: "historical" },
    { date: "2025-05-19", price: 341.8, type: "historical" },
    { date: "2025-05-20", price: 343.2, type: "historical" },
    { date: "2025-05-22", price: 339.4, type: "historical" },
    { date: "2025-05-23", price: 364.2, type: "historical" },
    { date: "2025-05-26", price: 357.8, type: "historical" },
    { date: "2025-05-27", price: 346.1, type: "historical" },
    { date: "2025-05-29", price: 343.7, type: "historical" },
    { date: "2025-06-02", price: 332.1, type: "historical" },
    { date: "2025-06-03", price: 285.2, type: "historical" },
    { date: "2025-06-05", price: 294.8, type: "historical" },
    { date: "2025-06-09", price: 308.7, type: "historical" },
    { date: "2025-06-10", price: 325.1, type: "historical" },
    { date: "2025-06-12", price: 327.8, type: "historical" },
    { date: "2025-06-13", price: 318.9, type: "historical" },
    { date: "2025-06-16", price: 325.31, type: "forecast" },
    { date: "2025-06-17", price: 325.31, type: "forecast" },
    { date: "2025-06-18", price: 325.31, type: "forecast" },
    { date: "2025-06-19", price: 325.31, type: "forecast" },
    { date: "2025-06-20", price: 325.31, type: "forecast" },
    { date: "2025-06-23", price: 325.31, type: "forecast" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <div className="border-b bg-white/80 backdrop-blur-sm dark:bg-slate-900/80">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-600 rounded-lg">
                <TrendingUp className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Multi-Model Stock Forecasting</h1>
                <p className="text-slate-600 dark:text-slate-400">
                  Advanced AI-powered stock price prediction platform
                </p>
              </div>
            </div>
            <Badge variant="secondary" className="px-3 py-1">
              <Activity className="h-4 w-4 mr-1" />
              Live Analysis
            </Badge>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <Tabs defaultValue="forecast" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 lg:w-[400px]">
            <TabsTrigger value="forecast" className="flex items-center gap-2">
              <Target className="h-4 w-4" />
              Multi-Model Forecast
            </TabsTrigger>
            <TabsTrigger value="optimization" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Model Optimization
            </TabsTrigger>
            <TabsTrigger value="prediction" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Final Forecast
            </TabsTrigger>
          </TabsList>

          {/* Multi-Model Forecast Tab */}
          <TabsContent value="forecast" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Stock Analysis Configuration
                </CardTitle>
                <CardDescription>Enter a stock ticker to analyze with multiple forecasting models</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-4">
                  <div className="flex-1">
                    <Input
                      placeholder="Enter Stock Ticker (e.g., TSLA)"
                      value={ticker}
                      onChange={(e) => setTicker(e.target.value.toUpperCase())}
                      className="text-lg"
                    />
                  </div>
                  <Button onClick={handleRunAnalysis} disabled={isAnalyzing} className="px-8" size="lg">
                    {isAnalyzing ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        Run Analysis
                      </>
                    )}
                  </Button>
                </div>

                {isAnalyzing && (
                  <div className="space-y-3">
                    <div className="text-sm text-slate-600 dark:text-slate-400">
                      Training models and evaluating performance...
                    </div>
                    <Progress value={65} className="w-full" />
                  </div>
                )}
              </CardContent>
            </Card>

            {analysisComplete && (
              <>
                <Alert className="border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-900/20">
                  <TrendingUp className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-800 dark:text-green-200">
                    <strong>
                      Best Model: {bestModel} (Accuracy: {(bestAccuracy * 100).toFixed(2)}%)
                    </strong>
                  </AlertDescription>
                </Alert>

                {/* Model Results for each model */}
                {Object.entries(evaluationData).map(([modelName, data]) => (
                  <div key={modelName} className="space-y-4">
                    <div className="flex items-center gap-2">
                      <h2 className="text-2xl font-bold">Model: {modelName}</h2>
                      {modelName === bestModel && <Badge className="bg-green-600">Best Model</Badge>}
                    </div>

                    <div className="grid gap-6 lg:grid-cols-2">
                      {/* Table 1: Evaluation Data */}
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">Table 1: Evaluation Data</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="overflow-x-auto">
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead className="w-12">Day</TableHead>
                                  <TableHead>Actual Price</TableHead>
                                  <TableHead>Predicted Price</TableHead>
                                  <TableHead>Previous Price</TableHead>
                                  <TableHead>Actual Direction</TableHead>
                                  <TableHead>Predicted Direction</TableHead>
                                  <TableHead>Comment</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {data.map((row) => (
                                  <TableRow key={row.day}>
                                    <TableCell>{row.day}</TableCell>
                                    <TableCell>{row.actualPrice.toFixed(2)}</TableCell>
                                    <TableCell>{row.predictedPrice.toFixed(4)}</TableCell>
                                    <TableCell>{row.previousPrice.toFixed(2)}</TableCell>
                                    <TableCell>
                                      <Badge variant={row.actualDirection === "UP" ? "default" : "secondary"}>
                                        {row.actualDirection}
                                      </Badge>
                                    </TableCell>
                                    <TableCell>
                                      <Badge variant={row.predictedDirection === "UP" ? "default" : "secondary"}>
                                        {row.predictedDirection}
                                      </Badge>
                                    </TableCell>
                                    <TableCell>
                                      {row.correct ? (
                                        <CheckCircle className="h-5 w-5 text-green-600" />
                                      ) : (
                                        <XCircle className="h-5 w-5 text-red-600" />
                                      )}
                                    </TableCell>
                                  </TableRow>
                                ))}
                              </TableBody>
                            </Table>
                          </div>
                        </CardContent>
                      </Card>

                      {/* Table 2: Confusion Matrix */}
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">Table 2: Confusion Matrix</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead></TableHead>
                                <TableHead>Predicted UP</TableHead>
                                <TableHead>Predicted DOWN</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              <TableRow>
                                <TableCell className="font-medium">Actual UP</TableCell>
                                <TableCell className="text-center font-bold">
                                  {confusionMatrixData[modelName as keyof typeof confusionMatrixData]?.tp || 0}
                                </TableCell>
                                <TableCell className="text-center font-bold">
                                  {confusionMatrixData[modelName as keyof typeof confusionMatrixData]?.fn || 0}
                                </TableCell>
                              </TableRow>
                              <TableRow>
                                <TableCell className="font-medium">Actual DOWN</TableCell>
                                <TableCell className="text-center font-bold">
                                  {confusionMatrixData[modelName as keyof typeof confusionMatrixData]?.fp || 0}
                                </TableCell>
                                <TableCell className="text-center font-bold">
                                  {confusionMatrixData[modelName as keyof typeof confusionMatrixData]?.tn || 0}
                                </TableCell>
                              </TableRow>
                            </TableBody>
                          </Table>
                        </CardContent>
                      </Card>
                    </div>

                    {/* Table 3: Classification Metrics */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Table 3: Classification Metrics</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Metric</TableHead>
                              <TableHead>Value</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            <TableRow>
                              <TableCell>Precision</TableCell>
                              <TableCell>
                                {(
                                  classificationMetrics[modelName as keyof typeof classificationMetrics]?.precision *
                                  100
                                ).toFixed(2)}
                                %
                              </TableCell>
                            </TableRow>
                            <TableRow>
                              <TableCell>Recall</TableCell>
                              <TableCell>
                                {(
                                  classificationMetrics[modelName as keyof typeof classificationMetrics]?.recall * 100
                                ).toFixed(2)}
                                %
                              </TableCell>
                            </TableRow>
                            <TableRow>
                              <TableCell>Accuracy</TableCell>
                              <TableCell>
                                {(
                                  classificationMetrics[modelName as keyof typeof classificationMetrics]?.accuracy * 100
                                ).toFixed(2)}
                                %
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </CardContent>
                    </Card>

                    <hr className="my-8" />
                  </div>
                ))}
              </>
            )}
          </TabsContent>

          {/* Model Optimization Tab */}
          <TabsContent value="optimization" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Model Optimization Experiments
                </CardTitle>
                <CardDescription>Fine-tune the best performing model with different parameters</CardDescription>
              </CardHeader>
              <CardContent>
                {!analysisComplete ? (
                  <Alert>
                    <Target className="h-4 w-4" />
                    <AlertDescription>
                      Please run the Multi-Model Forecast first to determine the best model for optimization.
                    </AlertDescription>
                  </Alert>
                ) : (
                  <div className="space-y-6">
                    <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                      <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">Optimizing: {bestModel}</h3>
                      <p className="text-blue-700 dark:text-blue-300 text-sm">
                        Running experiments with different forecasting horizons and training window sizes
                      </p>
                    </div>

                    {/* Experiment 1: Forecasting Horizons */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Experiment 1: Forecasting Horizons</CardTitle>
                        <CardDescription>Accuracy by Forecast Horizon:</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        {/* Data Table */}
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Horizon</TableHead>
                              <TableHead>Accuracy</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {horizonOptimizationData.map((row) => (
                              <TableRow key={row.horizon}>
                                <TableCell>{row.horizon}</TableCell>
                                <TableCell>{(row.accuracy * 100).toFixed(2)}%</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>

                        {/* Chart */}
                        <div>
                          <h4 className="font-semibold mb-4">Accuracy by Forecast Horizon</h4>
                          <ChartContainer
                            config={{
                              accuracy: {
                                label: "Accuracy",
                                color: "hsl(var(--chart-1))",
                              },
                            }}
                            className="h-[300px]"
                          >
                            <ResponsiveContainer width="100%" height="100%">
                              <BarChart data={horizonOptimizationData}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="horizon" />
                                <YAxis domain={[0, 100]} />
                                <ChartTooltip content={<ChartTooltipContent />} />
                                <Bar dataKey="accuracy" fill="var(--color-accuracy)" radius={[4, 4, 0, 0]} />
                              </BarChart>
                            </ResponsiveContainer>
                          </ChartContainer>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Experiment 2: Training Window Sizes */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Experiment 2: Training Window Sizes</CardTitle>
                        <CardDescription>Accuracy by Training Window Size:</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        {/* Data Table */}
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Window Size</TableHead>
                              <TableHead>Accuracy</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {windowOptimizationData.map((row) => (
                              <TableRow key={row.window}>
                                <TableCell>{row.window}</TableCell>
                                <TableCell>{(row.accuracy * 100).toFixed(2)}%</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>

                        {/* Chart */}
                        <div>
                          <h4 className="font-semibold mb-4">Accuracy by Training Window Size</h4>
                          <ChartContainer
                            config={{
                              accuracy: {
                                label: "Accuracy",
                                color: "hsl(var(--chart-2))",
                              },
                            }}
                            className="h-[300px]"
                          >
                            <ResponsiveContainer width="100%" height="100%">
                              <BarChart data={windowOptimizationData}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="window" />
                                <YAxis domain={[0, 100]} />
                                <ChartTooltip content={<ChartTooltipContent />} />
                                <Bar dataKey="accuracy" fill="var(--color-accuracy)" radius={[4, 4, 0, 0]} />
                              </BarChart>
                            </ResponsiveContainer>
                          </ChartContainer>
                        </div>
                      </CardContent>
                    </Card>

                    <Alert className="border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-900/20">
                      <Target className="h-4 w-4 text-green-600" />
                      <AlertDescription className="text-green-800 dark:text-green-200">
                        <strong>Optimal Configuration Found:</strong> 6-day horizon (83.33% accuracy) with 100-day
                        training window (46.67% accuracy)
                      </AlertDescription>
                    </Alert>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Final Forecast Tab */}
          <TabsContent value="prediction" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-3">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Current Price</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-slate-900 dark:text-white">$325.31</div>
                  <div className="text-sm text-slate-600 dark:text-slate-400 mt-1">{ticker} • Last updated</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">6-Day Forecast</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-blue-600">$325.31</div>
                  <div className="flex items-center gap-1 text-sm text-slate-600 mt-1">
                    <TrendingUp className="h-4 w-4" />
                    Stable (0.0%)
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Forecast Range</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-lg font-bold text-slate-900 dark:text-white">$325.31 - $325.31</div>
                  <div className="text-sm text-slate-600 dark:text-slate-400 mt-1">6-day price range</div>
                </CardContent>
              </Card>
            </div>

            {/* Main Forecast Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  {ticker} 6-Day Price Forecast
                </CardTitle>
                <CardDescription>Historical prices vs predicted future prices</CardDescription>
              </CardHeader>
              <CardContent>
                <ChartContainer
                  config={{
                    historical: {
                      label: "Historical Prices",
                      color: "hsl(220, 70%, 50%)",
                    },
                    forecast: {
                      label: "Forecasted Prices",
                      color: "hsl(0, 70%, 50%)",
                    },
                  }}
                  className="h-[500px]"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsLineChart data={finalForecastData} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" tick={{ fontSize: 12 }} angle={-45} textAnchor="end" height={80} />
                      <YAxis domain={[260, 380]} />
                      <ChartTooltip
                        content={<ChartTooltipContent />}
                        labelFormatter={(value) => `Date: ${value}`}
                        formatter={(value, name) => [`$${Number(value).toFixed(2)}`, name === "price" ? "Price" : name]}
                      />
                      <ChartLegend content={<ChartLegendContent />} />
                      <Line
                        dataKey="price"
                        stroke="hsl(220, 70%, 50%)"
                        strokeWidth={2}
                        dot={{ fill: "hsl(220, 70%, 50%)", strokeWidth: 2, r: 4 }}
                        connectNulls={false}
                        name="Historical Prices"
                        data={finalForecastData.filter((d) => d.type === "historical")}
                      />
                      <Line
                        dataKey="price"
                        stroke="hsl(0, 70%, 50%)"
                        strokeWidth={2}
                        strokeDasharray="5 5"
                        dot={{ fill: "hsl(0, 70%, 50%)", strokeWidth: 2, r: 4 }}
                        connectNulls={false}
                        name="Forecasted Prices"
                        data={finalForecastData.filter((d) => d.type === "forecast")}
                      />
                    </RechartsLineChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
