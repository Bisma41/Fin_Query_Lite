"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts"

const trendData = [
  { date: "Dec 15", price: 235.2, volume: 45000000, rsi: 52 },
  { date: "Dec 18", price: 238.1, volume: 42000000, rsi: 55 },
  { date: "Dec 19", price: 241.3, volume: 48000000, rsi: 58 },
  { date: "Dec 20", price: 239.8, volume: 44000000, rsi: 56 },
  { date: "Dec 21", price: 243.5, volume: 46000000, rsi: 61 },
  { date: "Dec 22", price: 246.8, volume: 43000000, rsi: 64 },
  { date: "Jan 15", price: 248.5, volume: 41000000, rsi: 66 },
  { date: "Jan 16", price: 251.2, volume: 39000000, rsi: 68 },
  { date: "Jan 17", price: 249.8, volume: 40000000, rsi: 67 },
  { date: "Jan 18", price: 253.4, volume: 38000000, rsi: 70 },
  { date: "Jan 19", price: 255.9, volume: 37000000, rsi: 72 },
  { date: "Jan 22", price: 258.3, volume: 36000000, rsi: 74 },
]

export function TrendAnalysisChart() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Technical Analysis Trend</CardTitle>
        <CardDescription>Price movement with volume and RSI indicators</CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer
          config={{
            price: {
              label: "Price",
              color: "hsl(var(--chart-1))",
            },
            volume: {
              label: "Volume",
              color: "hsl(var(--chart-3))",
            },
          }}
          className="h-[300px]"
        >
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trendData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
              <defs>
                <linearGradient id="priceGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="var(--color-price)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="var(--color-price)" stopOpacity={0.1} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <ChartTooltip
                content={<ChartTooltipContent />}
                formatter={(value, name) => {
                  if (name === "price") return [`$${Number(value).toFixed(2)}`, "Price"]
                  if (name === "volume") return [`${(Number(value) / 1000000).toFixed(1)}M`, "Volume"]
                  return [value, name]
                }}
              />
              <Area
                type="monotone"
                dataKey="price"
                stroke="var(--color-price)"
                fillOpacity={1}
                fill="url(#priceGradient)"
                strokeWidth={2}
              />
            </AreaChart>
          </ResponsiveContainer>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
