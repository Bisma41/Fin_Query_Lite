"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from "recharts"

const modelAccuracyData = [
  { name: "Prophet", value: 73, color: "hsl(var(--chart-1))" },
  { name: "Random Forest", value: 68, color: "hsl(var(--chart-2))" },
  { name: "XGBoost", value: 65, color: "hsl(var(--chart-3))" },
  { name: "Linear Regression", value: 61, color: "hsl(var(--chart-4))" },
  { name: "SMA Baseline", value: 58, color: "hsl(var(--chart-5))" },
]

export function ModelAccuracyDonut() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Model Accuracy Distribution</CardTitle>
        <CardDescription>Comparative accuracy scores across all models</CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer
          config={{
            prophet: { label: "Prophet", color: "hsl(var(--chart-1))" },
            randomForest: { label: "Random Forest", color: "hsl(var(--chart-2))" },
            xgboost: { label: "XGBoost", color: "hsl(var(--chart-3))" },
            linearRegression: { label: "Linear Regression", color: "hsl(var(--chart-4))" },
            smaBaseline: { label: "SMA Baseline", color: "hsl(var(--chart-5))" },
          }}
          className="h-[350px]"
        >
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={modelAccuracyData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={120}
                paddingAngle={2}
                dataKey="value"
              >
                {modelAccuracyData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <ChartTooltip content={<ChartTooltipContent />} formatter={(value, name) => [`${value}%`, name]} />
              <Legend
                verticalAlign="bottom"
                height={36}
                formatter={(value, entry) => `${value}: ${entry.payload.value}%`}
              />
            </PieChart>
          </ResponsiveContainer>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
